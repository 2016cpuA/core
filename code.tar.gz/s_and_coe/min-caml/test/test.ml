

let rec f x = x + 1 in if not (f 5) then () else ()
