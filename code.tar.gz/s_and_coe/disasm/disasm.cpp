#include <stdio.h>
#include <iostream>
#include <string>
#include <cstdint>
#include <bitset>

using namespace std;

const uint32_t op_mask = 0b11111100000000000000000000000000u;
const uint32_t d1_mask = 0b00000011111000000000000000000000u;
const uint32_t d2_mask = 0b00000000000111110000000000000000u;
const uint32_t d3_mask = 0b00000000000000001111100000000000u;
const uint32_t d4_mask = 0b00000000000000000000011111000000u;
const uint32_t d5_mask = 0b00000000000000000000000000111111u;

void dump_binary(uint32_t i) { cout << bitset<32>(i) << endl; }

void ignore_header() {
  string s;
  cin >> s >> s;
}

string reg(uint32_t i) { return "%r" + to_string(i); }
string freg(uint32_t i) { return "%f" + to_string(i); }

void dump_asm(string s) {
  uint32_t ins = 0;
  for (int i = 0; i < 8; i++) {
    ins += stoi(s.substr(i, 1), nullptr, 16) << 4 * (7 - i);
  }

  uint32_t op = (ins & op_mask) >> 26;
  uint32_t d1 = (ins & d1_mask) >> 21;
  uint32_t d2 = (ins & d2_mask) >> 16;
  uint32_t d3 = (ins & d3_mask) >> 11;
  uint32_t d4 = (ins & d4_mask) >> 6;
  uint32_t d5 = ins & d5_mask;

  switch (op) {
    case 0b000000: {  // Add And Jr Or Sll Slt Sra Srl Sub Xor
      switch (d5) {
        case 0b100000:  // Add
          cout << "add"
               << "\t" << reg(d3) << ", " << reg(d1) << ", " << reg(d2) << endl;
          break;
        case 0b100100:  // And
          cout << "and"
               << "\t" << reg(d3) << ", " << reg(d1) << ", " << reg(d2) << endl;
          break;
        case 0b001000:  // Jr
          cout << "jr"
               << "\t" << reg(d2) << endl;
          break;
        case 0b100101:  // Or
          cout << "or"
               << "\t" << reg(d3) << ", " << reg(d1) << ", " << reg(d2) << endl;
          break;
        case 0b000000:  // Sll
          cout << "sll"
               << "\t" << reg(d3) << ", " << reg(d2) << ", " << d4 << endl;
          break;
        case 0b101010:  // Slt
          cout << "slt"
               << "\t" << reg(d3) << ", " << reg(d1) << ", " << reg(d2) << endl;
          break;
        case 0b000011:  // Sra
          cout << "sra"
               << "\t" << reg(d3) << ", " << reg(d2) << ", " << d4 << endl;
          break;
        case 0b000010:  // Srl
          cout << "srl"
               << "\t" << reg(d3) << ", " << reg(d2) << ", " << d4 << endl;
          break;
        case 0b100010:  // Sub
          cout << "sub"
               << "\t" << reg(d3) << ", " << reg(d1) << ", " << reg(d2) << endl;
          break;
        case 0b100110:  // Xor
          cout << "xor"
               << "\t" << reg(d3) << ", " << reg(d1) << ", " << reg(d2) << endl;
          break;
        default:
          cerr << op << " " << d1 << " " << d2 << " " << d3 << " " << d4 << " "
               << d5 << endl;
          cerr << "unexpected case (at line " << __LINE__ << " of source file)"
               << endl;
      }
      break;
    }
    case 0b010001: {  // Add.s Mul.s Sub.s C.eq.s C.le.s C.lt.s Div.s
      switch (d5) {
        case 0b000000:  // Add.s
          cout << "add.s"
               << "\t" << freg(d4) << ", " << freg(d3) << ", " << freg(d2)
               << endl;
          break;
        case 0b000010:  // Mul.s
          cout << "mul.s"
               << "\t" << freg(d4) << ", " << freg(d3) << ", " << freg(d2)
               << endl;
          break;
        case 0b000001:  // Sub.s
          cout << "sub.s"
               << "\t" << freg(d4) << ", " << freg(d3) << ", " << freg(d2)
               << endl;
          break;
        case 0b111100:  // C.eq.s
          cout << "c.eq.s"
               << "\t" << reg(d4) << ", " << freg(d3) << ", " << freg(d2)
               << endl;
          break;
        case 0b111101:  // C.le.s
          cout << "c.le.s"
               << "\t" << reg(d4) << ", " << freg(d3) << ", " << freg(d2)
               << endl;
          break;
        case 0b111110:  // C.lt.s
          cout << "c.lt.s"
               << "\t" << reg(d4) << ", " << freg(d3) << ", " << freg(d2)
               << endl;
          break;
        case 0b000011:  // Div.s
          cout << "div.s"
               << "\t" << freg(d4) << ", " << freg(d3) << ", " << freg(d2)
               << endl;
          break;
        default:
          cerr << s << op << " " << d1 << " " << d2 << " " << d3 << " " << d4
               << " " << d5 << endl;
          cerr << "unexpected case (at line " << __LINE__ << " of source file)"
               << endl;
      }
      break;
    }
    case 0b001000:  // Addi
      cout << "addi"
           << "\t" << reg(d2) << ", " << reg(d1) << ", "
           << ((d3 << 11) + (d4 << 6) + d5) << endl;
      break;
    case 0b001100:  // Andi
      cout << "andi"
           << "\t" << reg(d2) << ", " << reg(d1) << ", "
           << ((d3 << 11) + (d4 << 6) + d5) << endl;
      break;
    case 0b000100:  // Beq
      cout << "beq"
           << "\t" << reg(d1) << ", " << reg(d2) << ", "
           << ((d3 << 11) + (d4 << 6) + d5) << endl;
      break;
    case 0b000101:  // Bne
      cout << "bne"
           << "\t" << reg(d1) << ", " << reg(d2) << ", "
           << ((d3 << 11) + (d4 << 6) + d5) << endl;
      break;
    case 0b111011:  // In
      cout << "in"
           << "\t" << reg(3) << endl;
      break;
    case 0b000010:  // J
      cout << "j"
           << "\t" << ((d1 << 21) + (d2 << 16) + (d3 << 11) + (d4 << 6) + d5)
           << endl;
      break;
    case 0b000011:  // Jal
      cout << "jal"
           << "\t" << ((d1 << 21) + (d2 << 16) + (d3 << 11) + (d4 << 6) + d5)
           << endl;
      break;
    case 0b100011:  // Lw
      cout << "lw"
           << "\t" << reg(d2) << ", " << ((d3 << 11) + (d4 << 6) + d5) << "("
           << reg(d1) << ")" << endl;
      break;
    case 0b110001:  // Lwc1
      cout << "lwc1"
           << "\t" << freg(d2) << ", " << ((d3 << 11) + (d4 << 6) + d5) << "("
           << reg(d1) << ")" << endl;
      break;
    case 0b001101:  // Ori
      cout << "ori"
           << "\t" << reg(d1) << ", " << reg(d2) << ", "
           << ((d3 << 11) + (d4 << 6) + d5) << endl;
      break;
    case 0b111100:  // Out
      cout << "out"
           << "\t" << reg(d1) << endl;
      break;
    case 0b101011:  // Sw
      cout << "sw"
           << "\t" << reg(d2) << ", " << ((d3 << 11) + (d4 << 6) + d5) << "("
           << reg(d1) << ")" << endl;
      break;
    case 0b111001:  // Swc1
      cout << "swc1"
           << "\t" << freg(d2) << ", " << ((d3 << 11) + (d4 << 6) + d5) << "("
           << reg(d1) << ")" << endl;
      break;
    default:
      cerr << op << " " << d1 << " " << d2 << " " << d3 << " " << d4 << " "
           << d5 << endl;
      cerr << "unexpected case (at line " << __LINE__ << " of source file)"
           << endl;
  }
}

int main() {
  ignore_header();
  string s;
  while (cin >> s) {
    dump_asm(s);
  }
}