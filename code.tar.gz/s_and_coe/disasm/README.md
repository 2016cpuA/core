
## Build

```
make
```

## Usage

```
./disasm < input.coe > output.s
```